#ifndef _COMMDEF_H_
#define _COMMDEF_H_
#include <math.h>
#include <float.h>
#include <ctype.h>
#include <string.h>

typedef double REAL;

//define data type
#ifndef BOOL
	#define BOOL int
#endif

#ifndef TRUE
	#define TRUE 1
#endif

#ifndef FALSE
	#define FALSE 0
#endif

#ifndef NULL
	#define NULL 0
#endif

#ifndef ELEMENTS
	#define ELEMENTS(array)		(sizeof(array)/sizeof((array)[0]))	//elements number of an arrray
#endif

#ifndef min
	#define min(x, y) ( (x)<=(y) ? (x) : (y) )
#endif
#ifndef max
	#define max(x, y) ( (x)>=(y) ? (x) : (y) )
#endif

#define setbit( a, i ) ( (a) |= (i) )
#define clrbit( a, i ) ( (a) &= ~(i) )
#define isset( a, i ) ( ((a) & (i)) != 0 )
#define isclr( a, i ) ( !isset( (a), (i) ) )

//swapping function
template<class T>
void swap( T& x, T& y )
{ T t = x; x = y; y = t; }

//double compare function
inline bool isflt_zero(float r)
{ return ((r+1.0)==1.0); }

inline bool isflt_equal(float r1, float r2, float eps=0)
{ return fabs(r1-r2)<=eps+FLT_EPSILON; }

inline bool isdbl_zero(double r)
{ return ((r+1.0)==1.0); }

inline bool isdbl_equal(double r1, double r2, double eps=0)
{ return fabs(r1-r2)<=eps+DBL_EPSILON; }

inline bool isrl_zero(REAL r)
{ return isdbl_zero(r); }

inline bool isrl_equal(REAL r1, REAL r2, REAL eps=0)
{ return isdbl_equal(r1,r2,eps); }

inline char* _tcsdec( char* start, char* current )
{
        return current>start ? current-1 : NULL;
}

inline char* _tcsinc( char* string )
{
        return string+1;
}

inline char* trimright( char* string )
{
        char *lpsz = string+strlen(string);

        lpsz = _tcsdec(string, lpsz);

        while( lpsz && isspace(*lpsz) )
                lpsz = _tcsdec(string, lpsz);

        if( lpsz==NULL )lpsz=string;
        else lpsz++;

        *lpsz = '\0';

        return string;
}

inline char* trimleft( char* string )
{
        char* lpsz = string;

        while (isspace(*lpsz))
                lpsz = _tcsinc(lpsz);

        if (lpsz != string)
        {
                // fix up data and length
                int nDataLength = (int)(strlen(string) - (lpsz - string));
                memmove(string, lpsz, (nDataLength+1)*sizeof(char));
        }
        return string;
}

inline char* trim( char* string )
{
	trimleft( string );
	return trimright( string );
}

#endif //_COMMDEF_H_


